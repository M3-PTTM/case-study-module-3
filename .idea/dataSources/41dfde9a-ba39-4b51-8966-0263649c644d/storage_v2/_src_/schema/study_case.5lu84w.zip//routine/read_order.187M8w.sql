create
    definer = root@localhost procedure read_order(IN in_order_id int)
BEGIN
    SELECT * FROM orders WHERE orders_id = in_order_id;
END;

