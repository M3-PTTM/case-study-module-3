create
    definer = root@localhost procedure delete_order(IN in_order_id int)
BEGIN
    DELETE FROM orders_product WHERE orders_id = in_order_id;
    DELETE FROM orders WHERE orders_id = in_order_id;
END;

