create
    definer = root@localhost procedure create_order(IN in_user_id int, IN in_order_quantity int,
                                                    IN in_order_status varchar(20))
BEGIN
    INSERT INTO orders (user_id, orders_quantity, orders_status, orders_date)
    VALUES (in_user_id, in_order_quantity, in_order_status, NOW());
END;

