create
    definer = root@localhost procedure update_order(IN in_order_id int, IN in_order_status varchar(20),
                                                    IN in_order_quantity int)
BEGIN
    UPDATE orders
    SET 
        orders_status = in_order_status,
        orders_quantity = in_order_quantity,
        orders_date = NOW()
    WHERE orders_id = in_order_id;
END;

