create definer = root@localhost trigger orders
    after delete
    on cart
    for each row
BEGIN
INSERT INTO orders (customer_id, product_id, quantity) VALUES
(OLD.customer_id, OLD.product_id, OLD.quantity);
END;

